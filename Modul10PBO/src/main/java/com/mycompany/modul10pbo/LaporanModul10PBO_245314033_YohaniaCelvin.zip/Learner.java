/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.modul10pbo;

/**
 *
 * @author Celvin Pati
 */
interface Learner {
    String getCourseGrade(); // Metode untuk mengembalikan nilai huruf (A-E)
}
