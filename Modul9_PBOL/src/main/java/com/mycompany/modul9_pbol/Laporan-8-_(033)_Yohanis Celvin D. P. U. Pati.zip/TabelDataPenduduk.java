/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.modul9_pbol;

/**
 *
 * @author Celvin Pati
 */
import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.table.AbstractTableModel;

public class TabelDataPenduduk extends JFrame {

    public static List<Penduduk> daftarPenduduk = new ArrayList<>();

    private JTable tabel;
    private JButton btnSegarkan;
    private JButton btnTutup;
    private JScrollPane scrollPane;

    public TabelDataPenduduk() {
        setTitle("DATA PENDUDUK");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(900, 400);
        setLocationRelativeTo(null);
        initComponents();
    }
    private void initComponents() {
       
        tabel = new JTable();
        scrollPane = new JScrollPane(tabel);
        btnSegarkan = new JButton("Segarkan");
        btnTutup = new JButton("Tutup");

        JPanel bottom = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 8));
        bottom.add(btnSegarkan);
        bottom.add(btnTutup);

        getContentPane().setLayout(new BorderLayout(8, 8));
        getContentPane().add(scrollPane, BorderLayout.CENTER);
        getContentPane().add(bottom, BorderLayout.SOUTH);

        refreshTableModel();

        btnSegarkan.addActionListener(e -> refreshTableModel());
        btnTutup.addActionListener(e -> dispose());
    }
    public void refreshTableModel() {
       
        tabel.setModel(new PendudukTableModel(daftarPenduduk));
       
        ((AbstractTableModel) tabel.getModel()).fireTableDataChanged();

    }
    public static void main(String[] args) {
        
        if (daftarPenduduk.isEmpty()) {
            Penduduk p1 = new Penduduk();
            p1.setNik("0123456789");
            p1.setNama("Budi Santoso");
            p1.setJenisKelamin("Laki-Laki");
            p1.setTanggalLahir("01/01/90");
            p1.setNoHp("081-234-567-890");
            p1.setAlamat("Jl. Kebon Jeruk");
            p1.setId("Budi90");
            p1.setPassword(new StringBuilder(p1.getNoHp()).reverse().toString());
            daftarPenduduk.add(p1);

            Penduduk p2 = new Penduduk();
            p2.setNik("9876543210");
            p2.setNama("Siti Aminah");
            p2.setJenisKelamin("Perempuan");
            p2.setTanggalLahir("02/02/91");
            p2.setNoHp("082-111-222-333");
            p2.setAlamat("Jl. Merdeka");
            p2.setId("Siti91");
            p2.setPassword(new StringBuilder(p2.getNoHp()).reverse().toString());
            daftarPenduduk.add(p2);
        }
        SwingUtilities.invokeLater(() -> {
            new TabelDataPenduduk().setVisible(true);
        });
    }
}
