/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.modul4pbofix;

/**
 *
 * @author Celvin Pati
 */
public class Mahasiswa {
   // bagian ini untuk deklarasi atribut mahasiswa
    String Nim;             // NIM mahasiswa
    String Nama;            // Nama mahasiswa
    String TanggalLahir;    // Tanggal lahir mahasiswa
    double Uts1;            // Nilai UTS pertama
    double Uts2;            // Nilai UTS kedua
    double Uas;             // Nilai UAS
    double Final;           // Nilai akhir mahasiswa (setelah perhitungan)
    String NilaiKonversi;   // Nilai huruf (A, B, C, D, atau E)

    // bagian ini adalah constructor: yang dipakai untuk menginisialisasi objek Mahasiswa
    public Mahasiswa(String Nim, String Nama, String TanggalLahir, double Uts1, double Uts2, double Uas) {
        this.Nim = Nim;                      // isi atribut Nim dengan nilai dari parameter
        this.Nama = Nama;                    // isi atribut Nama dengan nilai dari parameter
        this.TanggalLahir = TanggalLahir;    // isi atribut TanggalLahir dengan nilai dari parameter
        this.Uts1 = Uts1;                    // isi atribut Uts1 dengan nilai dari parameter
        this.Uts2 = Uts2;                    // isi atribut Uts2 dengan nilai dari parameter
        this.Uas = Uas;                      // isi atribut Uas dengan nilai dari parameter
        this.Final = hitungNilaiFinal();     // hitung dan menyimpan nilai akhir ke atribut Final
        this.NilaiKonversi = konversiNilai();// konversi nilai akhir ke huruf dan menyimpannya
    }

    // ini adalah method untuk hitung nilai akhir mahasiswa
    public double hitungNilaiFinal() {
        // Perhitungan nilai akhir dengan bobot:
        // 30% dari UTS1, 30% dari UTS2, dan 40% dari UAS
        return (0.3 * Uts1) + (0.3 * Uts2) + (0.4 * Uas);
    }

    // ini adalah method untuk konversi nilai akhir menjadi nilai huruf (A, B, C, D, E)
    public String konversiNilai() {
        if (Final >= 80) return "A";     // Jika nilai akhir >= 80, maka mendapatkan A
        else if (Final >= 70) return "B";// Jika nilai akhir 70 - 79, maka mendapatkan B
        else if (Final >= 56) return "C";// Jika nilai akhir 56 - 69, maka mendapatkan C
        else if (Final >= 45) return "D";// Jika nilai akhir 45 - 55, maka mendapatkan D
        else return "E";                 // Jika nilai akhir < 45, maka mendapatkan E
    }
}//akhir kelas mahasiswa

