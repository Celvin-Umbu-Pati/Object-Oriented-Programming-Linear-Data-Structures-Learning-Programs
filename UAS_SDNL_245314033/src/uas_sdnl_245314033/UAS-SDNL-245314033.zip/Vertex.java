/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package uas_sdnl_245314033;

/**
 *
 * @author Celvin Pati
 */
public class Vertex {
    public String label;
    public boolean visited;

    public Vertex(String label) {
        this.label = label;
        this.visited = false;
    }
}
