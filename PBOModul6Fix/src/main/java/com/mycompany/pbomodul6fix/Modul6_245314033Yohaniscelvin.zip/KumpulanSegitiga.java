/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.pbomodul6fix;

import java.util.ArrayList;

/**
 *
 * @author Celvin Pati
 */
public class KumpulanSegitiga {
    // Atribut untuk menyimpan jumlah segitiga dalam kumpulan
    private int jumlahSegitiga;
    // Atribut untuk menyimpan daftar segitiga menggunakan ArrayList
    private ArrayList<Segitiga> daftarSegitiga;

    // Konstruktor untuk inisialisasi awal
    public KumpulanSegitiga() {
        this.jumlahSegitiga = 0; // Inisialisasi jumlah segitiga = 0
        this.daftarSegitiga = new ArrayList<>(); // Inisialisasi ArrayList kosong
    }

    // Method untuk menambahkan segitiga ke dalam kumpulan
    // Parameter: objek Segitiga yang akan ditambahkan
    public void tambahSegitiga(Segitiga segitiga) {
        this.daftarSegitiga.add(segitiga); // Menambahkan ke ArrayList
        this.jumlahSegitiga++; // Menambah counter jumlah segitiga
    }

    // Method untuk menghitung rata-rata luas semua segitiga
    public double hitungRataRataLuas() {
        // Penanganan kasus ketika tidak ada segitiga
        if (jumlahSegitiga == 0) {
            return 0; // Mengembalikan 0 jika tidak ada segitiga
        }
        
        double totalLuas = 0;
        // Loop melalui semua segitiga dan akumulasi total luas
        for (Segitiga segitiga : daftarSegitiga) {
            totalLuas += segitiga.hitungLuas();
        }
        // Hitung rata-rata dengan membagi total dengan jumlah segitiga
        return totalLuas / jumlahSegitiga;
    }

    // Method untuk mencari segitiga dengan luas terbesar
    public Segitiga cariSegitigaTerluas() {
        // Penanganan kasus ketika tidak ada segitiga
        if (jumlahSegitiga == 0) {
            return null; // Mengembalikan null jika tidak ada segitiga
        }
        
        // Asumsikan segitiga pertama sebagai yang terluas
        Segitiga terluas = daftarSegitiga.get(0);
        // Loop untuk membandingkan dengan segitiga lainnya
        for (Segitiga segitiga : daftarSegitiga) {
            if (segitiga.hitungLuas() > terluas.hitungLuas()) {
                terluas = segitiga; // Update jika ditemukan yang lebih luas
            }
        }
        return terluas;
    }

    // Method untuk mencari segitiga dengan keliling terkecil
    public Segitiga cariSegitigaTerkecil() {
        // Penanganan kasus ketika tidak ada segitiga
        if (jumlahSegitiga == 0) {
            return null; // Mengembalikan null jika tidak ada segitiga
        }
        
        // Asumsikan segitiga pertama sebagai yang terkecil
        Segitiga terkecil = daftarSegitiga.get(0);
        // Loop untuk membandingkan dengan segitiga lainnya
        for (Segitiga segitiga : daftarSegitiga) {
            if (segitiga.hitungKeliling() < terkecil.hitungKeliling()) {
                terkecil = segitiga; // Update jika ditemukan yang lebih kecil
            }
        }
        return terkecil;
    }

    // Getter method untuk mendapatkan jumlah segitiga
    public int getJumlahSegitiga() {
        return jumlahSegitiga;
    }
}


