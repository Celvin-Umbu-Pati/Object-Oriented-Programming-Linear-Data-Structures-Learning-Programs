/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.uts_pbo_245314033;

/**
 *
 * @author Celvin Pati
 */
public class Pemain {
    private int nPunggung;
    private String nama;
    private int usia;
    
    public Pemain(int nPunggung, String nama){
        this.nPunggung = nPunggung;
        this.nama = nama;
        this.usia = usia;
    }
  public int setnPunggung(){
      return nPunggung;
  }
  public String setnama(){
      return nama;
  }
  public int setusia(){
      return usia;
  } 
  public int getnPunggung(){
      return nPunggung;
  }
  public String getnama(){
      return nama;
  }
  public int getusia(){
      return usia;
  }
          
}
