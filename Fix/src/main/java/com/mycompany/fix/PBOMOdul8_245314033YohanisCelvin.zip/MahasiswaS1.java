/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.fix;

/**
 *
 * @author Celvin Pati
 */
class MahasiswaS1 extends Mahasiswa {
    // Konstruktor Mahasiswa S1 memanggil konstruktor induk
    public MahasiswaS1(String Nim, String Nama, String TanggalLahir, 
                      double Uts1, double Uts2, double Uas) {
        super(Nim, Nama, TanggalLahir, Uts1, Uts2, Uas);
    }
}

